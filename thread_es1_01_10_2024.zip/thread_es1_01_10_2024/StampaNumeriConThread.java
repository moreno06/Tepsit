package thread_es1_01_10_2024;
import java.util.Scanner;

public class StampaNumeriConThread {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Inserisci il numero di thread: ");
        int t = scanner.nextInt();
        System.out.print("Inserisci il valore massimo: ");
        int n = scanner.nextInt();

        Contatore contatore = new Contatore(n);

        
        Thread_cont[] threads = new Thread_cont[t];
        for (int i = 0; i < t; i++) {
            threads[i] = new Thread_cont(contatore);
            threads[i].start();
        }
    }
}