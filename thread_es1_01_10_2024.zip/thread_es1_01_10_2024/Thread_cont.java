package thread_es1_01_10_2024;

public class Thread_cont extends Thread{
	private Contatore contatore;

    public Thread_cont(Contatore contatore) {
        this.contatore = contatore;
    }

    @Override
    public void run() {
        while (true) {
            int numero = contatore.Inc();
            if (numero == -1) {
                break; 
            }
            System.out.println(Thread.currentThread().getName() + " ha stampato: " + numero);
        }
    }
}

