package Thread_es2_01_10_2024;

public class Contatore {
	private int numeroCorrente = 1; 
    private int n;

    public Contatore(int n) {
        this.n = n;
    }

   
    public synchronized int Inc() {
        if (numeroCorrente <= n) {
            return numeroCorrente++; 
        }
        return -1;
    }
}
