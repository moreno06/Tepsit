package Thread_es2_01_10_2024;
import java.util.Scanner;

public class StampaNumeriConCoppieThread {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

     
        System.out.print("Inserisci il numero di thread (T, deve essere pari): ");
        int t = scanner.nextInt();
        System.out.print("Inserisci il valore massimo (N): ");
        int n = scanner.nextInt();

      
        Contatore[] contatori = new Contatore[t / 2]; //istanzio solo metà dei contatori
        for (int i = 0; i < t / 2; i++) {
            contatori[i] = new Contatore(n); 
        }

       
        Thread_cont[] threads = new Thread_cont[t];
        for (int i = 0; i < t; i++) {
            threads[i] = new Thread_cont(contatori[i / 2]); //gli passo ogni 2 volte lo stesso oggetto contatore
            threads[i].start();
        }

    }
}