package prod_e_cons_es1;

import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("dimensione buffer?");
		int d = scanner.nextInt();
		
		Buffer buffer = new Buffer(d);
		Produttore prod = new Produttore(buffer);
		Consumatore consum = new Consumatore(buffer);
		
		prod.start();
		consum.start();
	}

}
