package prod_e_cons_es1;

public class Buffer {
    private int[] buffer;
    private int testa, coda, cont;
    private int cap;

    public Buffer(int cap) {
        this.cap = cap;
        this.buffer = new int[cap];
        testa = 0;
        coda = 0;
        cont = 0;
    }

    public synchronized void inserisci(int val) throws InterruptedException {
        while (cont == cap) {
            wait();
        }

        buffer[coda] = val;
        coda = (coda + 1) % cap;
        cont++;
        notifyAll();
    }

    public synchronized int consuma() throws InterruptedException {
        while (cont == 0) {
            wait();
        }

        int val = buffer[testa];
        testa = (testa + 1) % cap;
        cont--;
        notifyAll();
        return val;
    }
}
