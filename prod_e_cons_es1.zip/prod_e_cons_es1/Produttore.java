package prod_e_cons_es1;

import java.util.Random;

public class Produttore extends Thread {
    private Buffer buffer;
    private Random random = new Random();

    public Produttore(Buffer buffer) {
    	this.buffer = buffer;
    }
    
    @Override
    public void run() {
    	
    	while(true) {
    		 try 
    		 {
				Thread.sleep(random.nextInt(901) + 100);
				int valore = random.nextInt(1024);
                buffer.inserisci(valore);
                System.out.println("sto inserendo un valore nel  buffer");
			 } 
    		 catch (InterruptedException e) 
    		 {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
    		
    	}
    	
    }
    
    
}