package prod_e_cons_es1;

public class Consumatore extends Thread{
	
	private int ContP = 0;
	private int ContD = 0;
	private Buffer buffer;
	
    public Consumatore(Buffer buffer) {
    	this.buffer = buffer;
    }
    
    @Override
    public void run() {
    	
    	
    	int cons;
		try {
			
			while(true) {
				cons = buffer.consuma();
				System.out.println("ho letto " + cons );
				
				if(cons%2 == 0) {
					ContP ++;
		    	}else {
		    		ContD++;
		    	}
				
				System.out.println("Stats: Num Pari: " + ContP + " Num Dispari: " + ContD  );
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }
    
}
