/**
 * 
 */
/**
 * 
 */
module JavaParty {
}