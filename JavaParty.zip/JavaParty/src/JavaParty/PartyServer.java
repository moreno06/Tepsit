package JavaParty;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PartyServer {

    // Lista per memorizzare i gestori dei client
    static List<ClientHandler> clientHandlers = new ArrayList<>();
    // Variabile per verificare se il gioco è finito
    static boolean gameEnded = false;
    static boolean primo = false;

    // Classe interna per gestire i client
    static class ClientHandler implements Runnable {

        // Posizioni e punteggi specifici per ogni client
        private int pos = 0;
        private int punteggio = 0;
        // Socket del client
        Socket link;
        private int id;
        private PrintWriter writer;
        private static int[] caselle = new int[10];
        private BufferedReader reader; // Campo corretto per BufferedReader

        // Inizializzazione del thread che associa il client
        public ClientHandler(Socket s, int id) {
            this.link = s;
            this.id = id;
        }

        // Metodo per chiudere il socket
        public void cleanup() {
            try {
                if (link != null && !link.isClosed()) {
                    link.close();
                }
            } catch (IOException e) {
                System.err.println("Errore nella chiusura del socket: " + e.getMessage());
            }
        }

        private void freccetteMiniGame() throws IOException {
            Random random = new Random();
            writer.println("Benvenuto al minigioco Freccette! (premi invio)");
            for (int tiri = 1; tiri <= 3; tiri++) {
                writer.println("Tiro " + tiri + ": Inserisci un numero da 1 a 10: (scrivi tira)");
                int freccia = Integer.parseInt(reader.readLine());
                int tabella = random.nextInt(10) + 1;

                writer.println("Numero scelto: " + freccia + " (premi invio)");
                writer.println("Numero corretto: " + tabella + " (premi invio)");

                int differenza = Math.abs(freccia - tabella);
                if (differenza == 0) {
                    punteggio += 10;
                    writer.println("Centro perfetto! +10 punti. (premi invio)");
                } else if (differenza <= 5) {
                    punteggio += 5;
                    writer.println("Vicino al bersaglio! +5 punti. (premi invio)");
                } else {
                    writer.println("Fuori bersaglio! Nessun punto. (premi invio)");
                }
            }
            writer.println("Punteggio aggiornato: " + punteggio + " (premi invio)");
        }

        public static void Porta() {
            System.out.println(" _______________________");
            for (int riga = 0; riga < 3; riga++) {
                System.out.print("|");
                for (int colonna = 1; colonna <= 3; colonna++) {
                    int numero = riga * 3 + colonna;
                    System.out.print(numero + "\t");
                }
                System.out.println("|");
            }
        }

        private void rigoriMiniGame() throws IOException {
            Random random = new Random();
            int parata1 = random.nextInt(9) + 1;
            int parata2;
            do {
                parata2 = random.nextInt(9) + 1;
            } while (parata2 == parata1);

            Porta();
            writer.println("Scegli una posizione da 1 a 9 per tirare: (scrivi tira)");
            int tiro = Integer.parseInt(reader.readLine());

            if (tiro != parata1 && tiro != parata2) {
                punteggio += 10;
                writer.println("GOAL! Hai guadagnato 10 punti! (premi invio)");
            } else {
                writer.println("Parata incredibile del portiere! Nessun punto. (premi invio)");
            }
            writer.println("Punteggio aggiornato: " + punteggio + " (premi invio)");
        }

        @Override
        public void run() {
            try {
                reader = new BufferedReader(new InputStreamReader(link.getInputStream())); // Usa il campo reader
                writer = new PrintWriter(link.getOutputStream(), true);

                for (int i = 0; i < 10; i++) {
                    Random punti = new Random();
                    caselle[i] = punti.nextInt(10);
                }

                while (!gameEnded) { // Il ciclo continua finché gameEnded è falso
                    try {
                        String message = reader.readLine();
                        if (message != null) {
                            try {
                                int tiro = Integer.parseInt(message);
                                System.out.println("Numero ricevuto dal client " + id + " tiro: " + tiro);

                                synchronized (PartyServer.class) {
                                    pos += tiro;

                                    if (pos == 2 || pos == 6 || pos == 8) {
                                        freccetteMiniGame();
                                    }

                                    if (pos == 5 || pos == 7 || pos == 9) {
                                        rigoriMiniGame();
                                    }

                                    if (pos >= caselle.length) {
                                        if (!primo) {
                                            primo = true;
                                            writer.println("Hai finito per primo! Hai vinto 10 pt bonus.");
                                            punteggio += 10;
                                        } else {
                                            writer.println("Hai finito per secondo :(  (premi invio)");
                                            gameEnded = true;

                                            // Calcola e notifica i risultati finali
                                            String ris = getFinalResults();
                                            notifyAllClients("fine");
                                            System.out.println(ris);
                                            System.out.println("Gioco finito client disconnessi");
                                        }
                                    } else {
                                        punteggio += caselle[pos];
                                        writer.println("Sei in posizione: " + pos + " punteggio casella [" + caselle[pos] + "] Punteggio attuale: " + punteggio);
                                    }
                                }
                            } catch (NumberFormatException e) {
                                writer.println("Echo: " + message);
                            }
                        }
                    } catch (IOException e) {
                        System.err.println("Errore durante la lettura del messaggio: " + e.getMessage());
                        break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                cleanup();
            }
        }

        public int getPunteggio() {
            return punteggio;
        }

        public int getId() {
            return id;
        }
    }

    public static String getFinalResults() {
        String results = "=== RISULTATI FINALI ===\n";
        int maxScore = -1;
        int winnerId = -1;

        synchronized (PartyServer.class) {
            for (ClientHandler handler : clientHandlers) {
                results += "Client " + handler.getId() + ": Punteggio finale: " + handler.getPunteggio() + "\n";
                if (handler.getPunteggio() > maxScore) {
                    maxScore = handler.getPunteggio();
                    winnerId = handler.getId();
                }
            }
        }
        results += "Il vincitore è il Client " + winnerId + " con " + maxScore + " punti!";
        return results;
    }

    private static void notifyAllClients(String message) {
        synchronized (PartyServer.class) {
            for (ClientHandler handler : clientHandlers) {
                if (handler.writer != null) {
                    handler.writer.println(message);
                }
            }
        }
    }

    public static void main(String[] args) {
        int port = 12345;

        try (ServerSocket server = new ServerSocket(port)) {
            System.out.println("Server avviato. In attesa di connessioni...");

            int Nclient = 0;
            while (true) {
                if (Nclient < 2) {
                    Socket clientSocket = server.accept();
                    ClientHandler clientHandler = new ClientHandler(clientSocket, Nclient + 1);
                    clientHandlers.add(clientHandler); // Usa la lista globale
                    Thread clientThread = new Thread(clientHandler);
                    clientThread.start();
                    Nclient++;
                }

                if (Nclient == 2) {
                    // Dice ai client che sono stati connessi
                    for (ClientHandler handler : clientHandlers) {
                        handler.writer.println("Benvenuto! Sei stato connesso a una partita!");
                    }
                    Nclient = 0;
                }
            }

        } catch (Exception e) {
            System.err.println("Errore del server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}