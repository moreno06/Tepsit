package JavaParty;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

public class PartyClient {
    public static void main(String[] args) {
        // Configura l'indirizzo IP e la porta del server
        String serverAddress = "127.0.0.1"; // IP del server (localhost)
        int port = 12345; // Porta del server
        boolean inGame = true;

        try {
            // Crea una connessione al server
            Socket socket = new Socket(serverAddress, port);

            // Ottiene l'output stream per inviare dati
            OutputStream out = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(out, true);

            // Ottiene l'input stream per ricevere dati
            InputStream in = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            // Messaggio di benvenuto dal server
            String welcomeMessage = reader.readLine();
            System.out.println(welcomeMessage);

            Random dado = new Random();
            Scanner scanner = new Scanner(System.in);

            while (inGame) {
                System.out.println("Scrivi 'tira' per poter tirare il dado: ");
                String word = scanner.nextLine();

                if ("tira".equalsIgnoreCase(word)) { // Quando l'utente scrive 'tira'
                    int tiro = dado.nextInt(6) + 1; // numero casuale tra 1 e 6
                    System.out.println("Ti sposterai di " + tiro + " caselle");
                    writer.println(tiro); // Invia il numero al server
                } else {
                    System.out.println("Comando non riconosciuto, per favore scrivi 'tira'.");
                }

                // Riceve i messaggi dal server
                String serverMessage = reader.readLine();
                if (serverMessage != null) {
                    if ("fine".equalsIgnoreCase(serverMessage)) {
                        inGame = false; // Fine del gioco
                    } else {
                        System.out.println(serverMessage); // Mostra altri messaggi del server
                    }
                }
            }

            System.out.println("Gioco finito!");
            socket.close(); // Chiude la connessione
        } catch (Exception e) {
            // Gestisce eventuali errori
            System.err.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }
    }
}