package thread_es3_01_10_2024;
import java.util.Scanner;

public class StatoDeiThread {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

	     
        System.out.print("Inserisci il numero di thread (T): ");
        int t = scanner.nextInt();
        System.out.print("Inserisci il valore massimo (N): ");
        int n = scanner.nextInt();
        
        
        Thread_contaX[] thread = new Thread_contaX[t];
        for(int i = 0; i < t; i++) {
        	thread[i] = new Thread_contaX(n);
        	thread[i].start();
        }
        
        boolean attivi = true;
        while(attivi) {
        	
        	attivi = false;
        	for(int i = 0; i < t; i++) {
        		
        		if(!(thread[i].isAlive())) {
        			System.out.println("Thread " + i + " TERMINATO");
            		
            	}else {
            		System.out.println("Thread " + i + " è attivo, contatore: " + thread[i].getNumCor());
            		attivi = true;
            	}
        	}
        	
        	try {
                Thread.sleep(1000);  
            } catch (InterruptedException e) {
                
            }
        }
        
        System.out.println("TUTTI I THREAD COMPLETATI");

	}

}
