package thread_es3_01_10_2024;

import java.util.Random;

public class Thread_contaX extends Thread{

	private int NumCor = 1;
	private int n;
	private int x;
	Random random = new Random();
	
	public Thread_contaX(int n) {
		this.n = n;
		x = random.nextInt(n + 1);
	}
	
    @Override
	public void run() {
    	try {
            while (NumCor <= x) {
                Thread.sleep(120); 
                NumCor++;
            }
        } catch (InterruptedException e) {
        	
        }
    }
    
    public int getNumCor() {
    	return NumCor;
    }
		
}
	
